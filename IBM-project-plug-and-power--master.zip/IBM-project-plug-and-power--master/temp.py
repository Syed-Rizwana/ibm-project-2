from flask import Flask, render_template, request, session,flash
import requests
import ibm_db


app = Flask(__name__)
app.secret_key ='a'

conn = ibm_db.connect("DATABASE=bludb;HOSTNAME=98538591-7217-4024-b027-8baa776ffad1.c3n41cmd0nqnrk39u98g.databases.appdomain.cloud;PORT=30875;SECURITY=SSL;SSLServerCertificate=DigiCertGlobalRootCA.crt;UID=xkm21060;PWD=YOhgP2fCDRHNdH16",'','')
print(conn)
print("connection successful...")
# =============================================================================
# url = "https://electric-vehicle-charging-stations.p.rapidapi.com/getByCordsAdv"
# querystring = {"lat":"40.733154296875","lng":"-73.99571228027344","radius":"10","page":"1","per_page":"10","access_param":"public","ev_connector_type_param":"J1772","ev_network_param":"Tesla,Tesla Destination","owner_type_param":"all"}
# headers = {
#  	"X-RapidAPI-Key": "05e6b8edccmsh7ef028db4983267p1abf89jsnc05651039ac0",
#  	"X-RapidAPI-Host": "electric-vehicle-charging-stations.p.rapidapi.com"
# }
# response = requests.get(url, headers=headers, params=querystring)
# print(response.json())
# =============================================================================
def insertdb(conn,stationName,streetAddress,city,state,zip,country,latitude,longitude):
    sql= "INSERT into charge VALUES('{}','{}','{}','{}','{}','{}','{}','{}')".format(stationName,streetAddress,city,state,zip,country,latitude,longitude)
    stmt = ibm_db.exec_immediate(conn, sql)
    print ("Number of affected rows: ", ibm_db.num_rows(stmt))
@app.route('/')
def index():
    return render_template('userprofile.html')

@app.route('/upload')
def upload():
    return render_template('registration.html')

@app.route('/confirm')
def confirm():
    return render_template('confirm.html')

@app.route('/nearchargestation')
def nearchargestation():
    return render_template('chargestationform.html')

@app.route('/getlocation')
def getlocation():
    return render_template('getloaction.html')

@app.route('/search', methods=['POST'])
def search():
    latitude = request.form['latitude']
    longitude = request.form['longitude']
    radius = request.form['radius']

    # You can now use these values to make the API request

    response_data = {
        'latitude': latitude,
        'longitude': longitude,
        'radius': radius
    }
    url = "https://vehicle-charging-stations.p.rapidapi.com/poi/"


    querystring = {"lat":latitude,"lng":longitude,"radius":radius,"Town":"Hyderabad"}

    headers = {
	"X-RapidAPI-Key": "c8b9e29db7msh8dbc2bd826f3700p1900d8jsna2ec4a07618e",
	"X-RapidAPI-Host": "vehicle-charging-stations.p.rapidapi.com"
}


    response = requests.get(url, headers=headers, params=querystring)
    data1=response.json()
    
    return render_template('index.html', data=data1)

     
@app.route('/register', methods=['POST','GET'])
def register():
    if request.method == "POST":
        stationName= request.form['stationName']
        streetAddress= request.form['streetAddress']
        city = request.form['city']
        state = request.form['state']
        zip = request.form['zip']
        country = request.form['country']
        latitude = request.form['latitude']
        longitude = request.form['longitude']        
        #inp=[name,email,contact,address,role,branch,password]
        insertdb(conn,stationName,streetAddress,city,state,zip,country,latitude,longitude)
        return render_template('registration.html')

if __name__ == '__main__':
    app.run(debug=True)
